sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("com.ztkt.assignment.controller.View1", {

        _consultantMap: {},

        onInit: function () {
            var sCss = ".sapMPage > section { padding: 0 !important; }" +
                       ".sapMPanel { margin-bottom: 0 !important; }";
            var oStyle = document.createElement("style");
            oStyle.appendChild(document.createTextNode(sCss));
            document.head.appendChild(oStyle);

            var oModel = this.getOwnerComponent().getModel();
            oModel.read("/ConsultantSet", {
                success: function (oData) {
                    oData.results.forEach(function (c) {
                        this._consultantMap[c.ConsId] = c.Name;
                    }.bind(this));
                    this.byId("tblSupport").getBinding("items").refresh();
                    this.byId("tblCR").getBinding("items").refresh();
                }.bind(this)
            });
        },

        formatConsName: function (sConsId, sModuleId) {
            var sName = this._consultantMap[sConsId] || sConsId;
            return (sModuleId || "") + " - " + sName;
        },

        onSideNavButtonPress: function () {
            var oToolPage = this.byId("toolPage");
            var bSideExpanded = oToolPage.getSideExpanded();
            oToolPage.setSideExpanded(!bSideExpanded);
        },

        onItemSelect: function (oEvent) {
            var sKey = oEvent.getParameter("item").getKey();
            console.log("Menu clicked:", sKey);
        }

    });
});